﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDb
{
    /// <summary>
    /// These is a context of data base 
    /// which consists of two tables 
    /// people and reviews
    /// </summary>
    public class DataBaseContext : DbContext
    {
        public DbSet<Person> People { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Articles> Articles { get; set; }
    }

    /// <summary>
    /// There is a class which help 
    /// us to initialize our data base
    /// </summary>
    public class DataBaseInitializer : DropCreateDatabaseAlways<DataBaseContext>
    {
        protected override void Seed(DataBaseContext context)
        {
            context.Reviews.Add(new Review("Lexa", "Дизайн отстой!", DateTime.Now));
            context.Reviews.Add(new Review("Kolia", "Дизайн крутой!", DateTime.Now));
            context.Articles.Add(new Articles { KeyWords = "Кулинария,Пища,Повар,Блюдо", Name = "Cooking", ImgPath = "../Content/img/1.jpg", TextPath = "~/Content/Articles/Cooking.txt" });
            context.Articles.Add(new Articles { KeyWords = "Масслкар,Авто,Водитель,Колесо" , Name = "Ford Mustang", ImgPath = "../Content/img/2.jpg", TextPath = "~/Content/Articles/Ford.txt" });
            context.Articles.Add(new Articles { KeyWords = "Масслкар,Авто,Водитель,Колесо,Марка", Name = "BMW", ImgPath = "../Content/img/3.jpg", TextPath = "~/Content/Articles/BMW.txt" });
            context.Articles.Add(new Articles { KeyWords = "Пинцет,Скальпель,Диета,Врач", Name = "Medicine", ImgPath = "../Content/img/4.jpg", TextPath = "~/Content/Articles/Medicine.txt" });
            base.Seed(context);
        }
    } 
}
