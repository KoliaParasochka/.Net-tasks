﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ProjectDb
{
    /// <summary>
    /// There is a class which describe a review
    /// </summary>
    public class Review
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Введите ваше имя")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Минимальная длинна строки 3 символа, а максимальная - 50 символов")]
        public string Author { get; set; }


        [Required(ErrorMessage = "Введите сообщение")]
        public string Text { get; set; }

        public DateTime Date { get; set; }

        public Review()
        {
            Text = string.Empty;
            Author = string.Empty;
            Date = DateTime.Now;
        }

        public Review(string author, string text, DateTime date)
        {
            Author = author;
            Text = text;
            Date = date;
        }
    }
}
