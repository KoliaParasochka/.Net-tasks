﻿using System.ComponentModel.DataAnnotations;

namespace ProjectDb
{
    /// <summary>
    /// There is a class which descripe a person
    /// </summary>
    public class Person
    {
        public int Id { get; set; }

        public string Name { get; private set; }
     
        public string LastName { get; private set; }
   
        public string Male { get; private set; }

        
        public string Female { get; private set; }

        
        public string HasJob { get; private set; }

        
        public string HasChildren { get; private set; }

        
        public string HasCar { get; private set; }

        public Person()
        {
            Name = string.Empty;
            LastName = string.Empty;
            Male = string.Empty;
            Female = string.Empty;
            HasJob = string.Empty;
            HasChildren = string.Empty;
            HasCar = string.Empty;
        }

        public Person(string name, string lastName, string male, string female, string hasJob, string hasChildren,
            string hasCar)
        {
            Name = name;
            LastName = lastName;
            Male = male;
            Female = female;
            HasJob = hasJob;
            HasCar = hasCar;
            HasChildren = hasChildren;
        }
    }
}
