﻿using ProjectDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Storages;

namespace WebApplication1.Controllers
{
    /// <summary>
    /// This controller works with reviews
    /// </summary>
    public class ReviewController : Controller
    {
        // We need to create a value to work whith class 'Storage'.
        Storage storage = new Storage();

        // GET: Review
        public ActionResult Index()
        {
            // We recerect client to action 'Index' of home controller to be returned to main page.
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// Here we get information from client 
        /// and post it to data base.
        /// </summary>
        /// <param name="author"></param>
        /// <param name="remark"></param>
        /// <returns></returns>

        [HttpPost]
        public ActionResult Remark(Review review)/*string author, string remark*/
        {
            if (ModelState.IsValid)
            {
                //Review review = new Review(author, text, DateTime.Now);
                storage.AddReview(review);
                return RedirectToAction("Guest");
            }
            else
            {
                return RedirectToAction("Guest");
            }
           

            
        }


        /// <summary>
        /// Here we get information from data base.
        /// </summary>
        /// <returns></returns>
        public ActionResult Guest()
        {
            ViewBag.Remarks = storage.GetReviews();
            return View();
        }

        [HttpPost]
        public ActionResult Guest(Review review)
        {
            if (string.IsNullOrEmpty(review.Author))
            {
                ModelState.AddModelError("Author", "Введите имя");

            }
            if (string.IsNullOrEmpty(review.Text))
            {
                ModelState.AddModelError("Text", "Введите текст вашего сообщения");

            }
            if (ModelState.IsValid)
            {
                storage.AddReview(review);
            }
            ViewBag.Remarks = storage.GetReviews();
           
            return View();
        }
    }
}