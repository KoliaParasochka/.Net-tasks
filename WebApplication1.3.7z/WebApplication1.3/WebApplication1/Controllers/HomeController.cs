﻿using ProjectDb;
using System.Collections.Generic;
using System.Web.Mvc;
using WebApplication1.FileWork;
using WebApplication1.Storages;

namespace WebApplication1.Controllers
{
    /// <summary>
    /// This controller works whith main page.
    /// </summary>
    public class HomeController : Controller
    {
        FileManager fileManage = new FileManager();
        
        public ActionResult Index()
        {
            Storage storage = new Storage();
            ViewBag.Articles = storage.GetArticles();
            return View();
        }

        [HttpPost]
        public ActionResult Read(string Name, string Path, string KeyWords)
        {
            Storage storage = new Storage();
            string fullPath = Server.MapPath(Path);
            ViewBag.Name = Name;
            ViewBag.KeyWords = KeyWords;
            ViewBag.Content = ReadFile(fullPath);
            return View();
        }

        [HttpGet]
        public string[] ReadFile(string path)
        {
            string[] lines = fileManage.GetLines(path);
            return lines;
        }

        private int CountOf(string s)
        {
            int count = 0;
            for(int i = 0; i < s.Length; i++)
            {
                if (s[i] == ',')
                    count++;
            }
            return count;
        }

        [HttpPost]
        public ActionResult Choise(string Cooking, string BMW, string Ford, string Medicine)
        {
            if (Cooking != null)
                ViewBag.Chosen = Cooking;
            else if (BMW != null)
                ViewBag.Chosen = BMW;
            else if (Medicine != null)
                ViewBag.Chosen = Medicine;
            else if (Ford != null)
                ViewBag.Chosen = Ford;
            return View();
        }
    }
}