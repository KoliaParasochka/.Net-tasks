﻿using ProjectDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Storages;

namespace WebApplication1.Controllers
{
    /// <summary>
    /// There is a controlloler
    /// which works with profile.
    /// </summary>
    public class ProfileController : Controller
    {
        Storage storage = new Storage();
        // GET: Profile
        public ActionResult Index()
        {
            // We recerect client to action 'Index' of home controller to be returned to main page.
            return RedirectToAction("Index", "Home");
        }

        /// <summary>
        /// There is a start method 
        /// for page apply.
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public ActionResult Apply()
        {
            ViewBag.Message = "Введите сюда информацию о себе";
            return View();
        }

        /// <summary>
        /// Here we get information from client side
        /// and post it to our data base.
        /// </summary>
        /// <param name="name"></param>
        /// <param name="lastName"></param>
        /// <param name="hasJob"></param>
        /// <param name="hasCar"></param>
        /// <param name="hasChildren"></param>
        /// <param name="male"></param>
        /// <param name="female"></param>
        /// <returns></returns>

        [HttpPost]
        public ActionResult Apply(string name, string lastName, string hasJob, string hasCar,
        string hasChildren, string male, string female)
        {
            Person person = new Person(name, lastName, male, female, hasJob, hasChildren, hasCar);
            storage.AddPerson(person);
            return RedirectToAction("CheckInfo");
        }

        /// <summary>
        /// There is a method which takes 
        /// people wrom our data base.
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public ActionResult CheckInfo()
        {
            ViewBag.People = storage.GetPeople();
            return View();
        }
    }
}