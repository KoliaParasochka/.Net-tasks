﻿using ProjectDb;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Storages
{
    /// <summary>
    /// There is a class which works with data base.
    /// </summary>
    public class Storage
    {   
        //public Articles GetKeyWords(string Name)
        //{
        //    using (DataBaseContext db = new DataBaseContext())
        //    {
        //        return db.Articles.Find(Name);
        //    }
        //}

        public List<Articles> GetArticles()
        {
            using (DataBaseContext db = new DataBaseContext())
            {
                return db.Articles.ToList<Articles>();
            }
        }


        /// <summary>
        /// This method addd person to data base.
        /// </summary>
        /// <param name="person"></param>
        public void AddPerson(Person person)
        {
            using (DataBaseContext db = new DataBaseContext())
            {
                db.People.Add(person);
                db.SaveChanges();
            }
        } 

        /// <summary>
        /// This method adds review to data base.
        /// </summary>
        /// <param name="review"></param>
        public void AddReview(Review review)
        {
            using (DataBaseContext db = new DataBaseContext())
            {
                db.Reviews.Add(review);
                db.SaveChanges();
            }
        }


        /// <summary>
        /// This method takes people from data base.
        /// </summary>
        /// <returns></returns>
        public List<Person> GetPeople()
        {
            using (DataBaseContext db = new DataBaseContext())
            {
                return db.People.ToList<Person>();
            }
        }

        /// <summary>
        /// This method takes reviews from data base.
        /// </summary>
        /// <returns></returns>

        public List<Review> GetReviews()
        {
            using (DataBaseContext db = new DataBaseContext())
            {
                return db.Reviews.ToList<Review>();
            }
        }
    }
}