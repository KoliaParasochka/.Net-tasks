﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDb
{
    /// <summary>
    /// These is a context of data base 
    /// which consists of two tables 
    /// people and reviews
    /// </summary>
    public class DataBaseContext : DbContext
    {
        public DbSet<Person> People { get; set; }
        public DbSet<Review> Reviews { get; set; }
    }

    /// <summary>
    /// There is a class which help 
    /// us to initialize our data base
    /// </summary>
    public class DataBaseInitializer : DropCreateDatabaseAlways<DataBaseContext>
    {
        protected override void Seed(DataBaseContext context)
        {
            context.Reviews.Add(new Review("Lexa", "Дизайн отстой!", DateTime.Now));
            context.Reviews.Add(new Review("Kolia", "Дизайн крутой!", DateTime.Now));
            base.Seed(context);
        }
    } 
}
