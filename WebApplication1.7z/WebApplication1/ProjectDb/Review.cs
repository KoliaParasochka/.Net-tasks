﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectDb
{
    /// <summary>
    /// There is a class which describe a review
    /// </summary>
    public class Review
    {
        public int Id { get; set; }
        public string Author { get; private set; }
        public string Text { get; private set; }
        public DateTime Date { get; private set; }

        public Review()
        {
            Author = "";
            Text = "";
            Date = DateTime.Now;
        }

        public Review(string author, string text, DateTime date)
        {
            Author = author;
            Text = text;
            Date = date;
        }
    }
}
