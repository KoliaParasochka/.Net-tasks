﻿using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    /// <summary>
    /// This controller works whith main page.
    /// </summary>
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}